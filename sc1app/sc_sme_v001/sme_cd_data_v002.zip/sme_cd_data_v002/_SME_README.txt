Draft, Uncontrolled, Unofficial  Set of Matrix Examples 

At the most basic level, object grouping can be divided into three types. The first type of object interface grouping focuses the interfaces along the matrix diagonal. The second type of object interface grouping focuses the interfaces in the lower triangular section of the matrix. The third type of object interface grouping focuses the interfaces in the upper triangular section of the matrix. These three basic types are the first to be addressed by the standard matrix example set.

Each standard matrix has a size N, establishing an N by N square matrix. Each standard matrix has a specific number of connections. The “percent-full” gives an indication of the matrix interface density. “Percent-full” is found by dividing the number of specific interface realations in the matrix, by the number of possible relational interface that could exixt. A matrix that is 100 percent full will not respond well to many types of analysis and evaluation. As described in the working paper, a matrix with a minimum number of interfaces (N-1) is also expected to perform poorly under many types of analysis and evaluation. The best results for automated analysis and evaluation are expected from matrices that have a percent-full rating of around 20 to 40 percent. One use being made of the set of standard matrix examples is testing of these expectations.

Assuming a matrix that has an object (or named entity) in each cell along the diagonal, the remaining matrix cells can have an entry in each row or there can be rows in the matrix with no entries. This basic difference in matrix structure (empty rows or no empty rows) also impacts matrix methods and evaluation approaches. The first set of standard examples addresses matrices with an object along the diagonal, and rows that have at least one entry in each row.

A naming convention has been developed to clearly identify each type of standard matrix. Each matrix name has the following components:

Name base for standard matrix example, SME, Analysis type, for example: grouping-diagonal:CD, grouping-upper-triangular:CU, grouping-lower-triangular:CL

Matrix size N, for example: 16, Interface percent-full, for example: 20 percent, 20P

Empty rows or no empty rows: no empty rows, NER 

Configuration type, ordered or disordered, for example disordered, DO

This results in a complete name of SME_CD_16_20P_NER_DO

The first set of standard matrix examples will be developed for the following sizes:

9x9 16 x 16 25 x 25 36 x 36 49 x 49 64 x 64 81 x 81 100 x 100 121 x 121 144 x 144

The minimum interface percent-full is:
9 x 9 = 8/72 = 11.1 percent
16 x 16 = 15/240 = 6.25 percent 
25 x 25 = 24/600 = 4.0 percent 
36 x 36 = 35/1260 = 2.8 percent 
49 x 49 = 48/2352 = 2.0 percent 
64 x 64 = 63/4032 = 1.6 percent 
81 x 81 = 80/6480 = 1.3 percent 
100 x 100 = 99/9900 = 1.0 percent 
121 x 121 = 120/14520 = 0.8 percent 
144 x 144 = 143/20592 = 0.7 percent

The complete set of standard matrix examples is composed of the following percent-full interface values for each matrix size:
5 percent (except for 9 x 9 and 16 x 16 based on the previous “minimum interface full values”) 
10 percent (except for 9 x 9 based on the previous “minimum interface full values”) 
15 percent 
20 percent
25 percent
30 percent 
35 percent 
40 percent 
45 percent 
50 percent

Each size of matrix will have an example for each of the percent-full interface values. The complete set of standard examples for the described diagonal grouping is then approximately 100 matrix pairs (one base and one grouped or partitioned), for a total of 200 matrices. In a similar fashion the upper triangular will have 200 matrices and the lower triangular grouping example sets will have 200 matrices. This comprises a total of around 600 matrices for the complete basic standard matrix set with no empty rows.

When matrices with empty rows are added to the above basic standard set, the expanded standard matrix set contains 1200 matrices. If the static and time-based matrix representations are addressed, that would create a standard matrix example set of 2400 matrices.

These matrices will be developed, published and discussed in an incremental fashion to encourage the development, comparison and discussion of common, verifiable matrix clustering algorithms and methods. The smaller-sized matrices are expected to perform well at all listed percent-full values. The larger matrices may not perform well at the higher percent-full values; and smaller percent values may need to be generated.

